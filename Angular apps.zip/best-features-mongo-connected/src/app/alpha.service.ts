import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import { Player } from './player';

@Injectable({
  providedIn: 'root'
})
export class AlphaService {

  constructor(private http: HttpClient) { }

  addPlayer(player: Player): Observable<any>{
    return this.http.post('http://localhost:3000/add', player);
  }

  getAllPlayers(): Observable<any>{
    return this.http.get('http://localhost:3000/all');
  }

  deleteAllPlayers(): Observable<any> {
    return this.http.post('http://localhost:3000/delete-all', {});
  }
}
