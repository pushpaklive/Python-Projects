# import requests 
# URL = "http://learn-javascript.in/"
# r = requests.get(URL) 
# print(r.content)


# -------------------------------------------------------------------------

# import requests 
# from bs4 import BeautifulSoup 

# URL = "http://learn-javascript.in/"
# r = requests.get(URL) 

# soup = BeautifulSoup(r.content, 'html5lib') 
# print(soup.prettify()) 

import requests 
from bs4 import BeautifulSoup 

URL = "https://bmostech.in/"
r = requests.get(URL) 

soup = BeautifulSoup(r.content, 'html5lib') 

table = soup.findAll('p') 

print(table)
for row in table:
    print(row.text)