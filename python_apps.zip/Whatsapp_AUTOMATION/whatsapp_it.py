import pywhatkit

# pywhatkit.sendwhatmsg('+919404320144', 'Oyeee  - from python', 19, 19)

# pywhatkit.info("Python",lines=3)

pywhatkit.playonyt("Python")
