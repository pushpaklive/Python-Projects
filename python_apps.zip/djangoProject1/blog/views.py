from django.http import HttpResponsedef index(request):
    return HttpResponse("Hello Medium, this is a new blog post")