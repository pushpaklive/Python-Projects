from flask import Flask, render_template, request, redirect
import speech_recognition as sr
import wave

app = Flask(__name__)

# @app.route("/", methods=["GET", "POST"])
# def index():
# 	return "Hello World"


# @app.route("/", methods=["GET", "POST"])
# def index():
#     if request.method == "POST":
#      print("POST request received!")
#     return render_template('index.html')

@app.route("/", methods=["GET", "POST"])
def index():
    transcript = ""
    if request.method == "POST":
        print("FORM DATA RECEIVED")

        if "file" not in request.files:
            return redirect(request.url)

        file = request.files["file"]
        print("request : ", request)
        print("file : ", file)
        if file.filename == "":
            return redirect(request.url)

        if file:
            recognizer = sr.Recognizer()
            audioFile = sr.AudioFile(file)
            obj = wave.open(file, 'r')


            print("Number of channels", obj)
            print("Sample width", obj.getsampwidth())
            print("Frame rate.", obj.getframerate())
            print("Number of frames", obj.getnframes())
            print("parameters:", obj.getparams())
            print("writeframes : ", obj.writeframes())
            obj.close()
            with audioFile as source:
                data = recognizer.record(source)
            transcript = recognizer.recognize_google(data, key=None)

    return render_template('index.html', transcript=transcript)


if __name__ == "__main__":
    app.run(debug=True, threaded=True)
